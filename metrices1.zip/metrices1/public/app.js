var app=angular.module('App', ['ngMaterial','ngAnimate','ngMessages']);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {


app.controller('demoController', function($scope,$http) {

  $scope.user = null;
$scope.users = null;
$scope.operations =[
  { id: 1, name: 'Addition' },
  { id: 2, name: 'Subtraction' },
  { id: 3, name: 'Multiplication' },
  { id: 4, name: 'Division' }
];
  $http.get('http://localhost:8080/header').then(function(data){
    $scope.header=data.data;
  });
$scope.loadoperation = function() {
  $http.get('http://localhost:8080/new/'+$scope.currentop.id+'/'+$scope.lefthead+'/'+$scope.righthead).then(function(data) {
    console.log(data.data);
    $scope.myrecord=data.data;
    // $scope.tooltipFunc = function(branch) {
    // 	return branch.name;
    // };
        // $scope.myStyle="width:150px;height:100px;"
      });

};
  $scope.hi="hi";


		 });
